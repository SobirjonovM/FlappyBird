using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Obstacles : MonoBehaviour
{
    public float speed = 5f; // Set a default speed
    
    private void FixedUpdate()
    {
        if (!FindObjectOfType<GameManager>().birdBek.isDead)
        {
            transform.position += (Vector3.left * speed * Time.deltaTime);
        }
    }
}

