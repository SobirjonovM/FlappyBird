using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed = 5.0f; // Control the speed
    private Rigidbody2D rb;
    public bool isDead = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        if (isDead) return; // Stop processing input if dead

        if (Input.GetMouseButtonDown(0))
        {
            rb.velocity = Vector2.up * speed;
        }
    }

    private void OnCollisionEnter2D(Collision2D other)
    {
        isDead = true;
        FindObjectOfType<GameManager>().GameOver(); // Call GameOver when colliding
    }
}
